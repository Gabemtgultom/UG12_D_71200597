print("Pilihan model Matematika")
print('1. Perkalian')
print('2. Pembagian')

pilihan = int(input("Masukkan model matematika yang diinginkan 1/2 : "))
angka = int(input('Menampilkan table matematika dari angka: '))

if pilihan == 1:
    for i in range(1,11):
        print(f'{angka} x {i} = {angka*i}')
elif pilihan == 2:
    for i in range(50,66):
        print(f'{i} : {angka} = {i/angka}')
else:
    print('tdk tersedia')